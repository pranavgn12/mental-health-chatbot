from datetime import datetime

from sqlalchemy import (
    Column,
    Integer,
    String,
    Text,
    DateTime,
    ForeignKey,
    JSON,
    Float
)

from database import Base


# =========================================================
# USER
# =========================================================

class User(Base):

    __tablename__ = "users"

    id = Column(
        Integer,
        primary_key=True
    )

    username = Column(
        String(50),
        unique=True
    )

    email = Column(
        String(100),
        unique=True
    )

    password_hash = Column(
        String(255)
    )


# =========================================================
# CONVERSATION
# =========================================================

class Conversation(Base):

    __tablename__ = "conversations"

    id = Column(
        Integer,
        primary_key=True
    )

    user_id = Column(
        Integer,
        ForeignKey("users.id")
    )

    title = Column(
        String(255)
    )

    system_prompt = Column(
        Text
    )

    # Rolling conversational context. Message rows remain the canonical history.
    context_summary = Column(Text, nullable=True)
    summary_through_message_id = Column(Integer, nullable=True)
    summary_updated_at = Column(DateTime, nullable=True)


# =========================================================
# MESSAGE
# =========================================================

class Message(Base):

    __tablename__ = "messages"

    id = Column(
        Integer,
        primary_key=True
    )

    conversation_id = Column(
        Integer,
        ForeignKey("conversations.id")
    )

    role = Column(
        String(20)
    )

    content = Column(
        Text
    )

    # Nullable for legacy messages and messages outside tracked episodes.
    episode_id = Column(
        String(20),
        ForeignKey("episodes.episode_id"),
        nullable=True,
        index=True
    )

    # Selected RAG/web sources used for this assistant response.
    source_references = Column(
        JSON,
        nullable=True
    )


# =========================================================
# EPISODE
# =========================================================

class Episode(Base):

    __tablename__ = "episodes"

    id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    episode_id = Column(
        String(20),
        unique=True,
        nullable=False
    )

    user_id = Column(
        Integer,
        ForeignKey("users.id"),
        nullable=False
    )

    title = Column(
        String(255),
        nullable=False
    )

    summary = Column(
        Text,
        nullable=True
    )

    status = Column(
        String(20),
        default="ACTIVE",
        nullable=False
    )

    # MySQL UNIQUE permits multiple NULLs. Setting this to user_id only
    # while ACTIVE enforces at most one active episode per user.
    active_user_id = Column(
        Integer,
        ForeignKey("users.id"),
        unique=True,
        nullable=True
    )

    created_at = Column(
        DateTime,
        default=datetime.utcnow
    )

    updated_at = Column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )

    closed_at = Column(
        DateTime,
        nullable=True
    )

    messages_since_last_mood = Column(
        Integer,
        default=0,
        nullable=False
    )

    messages_since_last_reflection = Column(
        Integer,
        default=0,
        nullable=False
    )


# =========================================================
# EPISODE MOOD
# =========================================================

class EpisodeMood(Base):

    __tablename__ = "episode_moods"

    id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    episode_id = Column(
        String(20),
        ForeignKey("episodes.episode_id"),
        nullable=False
    )

    mood = Column(
        String(100),
        nullable=False
    )

    message_id = Column(
        Integer,
        ForeignKey("messages.id"),
        nullable=True,
        unique=True
    )

    confidence = Column(Float, nullable=True)
    evidence = Column(Text, nullable=True)

    created_at = Column(
        DateTime,
        default=datetime.utcnow
    )


# =========================================================
# EPISODE REFLECTION
# =========================================================

class EpisodeReflection(Base):

    __tablename__ = "episode_reflections"

    id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    episode_id = Column(
        String(20),
        ForeignKey("episodes.episode_id"),
        nullable=False
    )

    reflection = Column(
        Text,
        nullable=False
    )

    created_at = Column(
        DateTime,
        default=datetime.utcnow
    )


# =========================================================
# LONG-TERM MEMORY
# =========================================================

class LongTermMemory(Base):

    __tablename__ = "long_term_memory"

    id = Column(
        Integer,
        primary_key=True,
        autoincrement=True
    )

    user_id = Column(
        Integer,
        ForeignKey("users.id"),
        nullable=False,
        unique=True
    )

    # Complete consolidated memory generated by the LLM.
    memory = Column(
        Text,
        nullable=False
    )

    # LLM-generated Profile themes.
    #
    # Example:
    # [
    #     {
    #         "id": "theme_01",
    #         "category": "Feeling",
    #         "title": "Anxious",
    #         "summary": "Worries about the future...",
    #         "details": "Full supporting memory...",
    #         "tone": "amber"
    #     }
    # ]
    #
    # Stored as JSON so React can directly render the themes.

    profile_themes = Column(
        JSON,
        nullable=True
    )

    updated_at = Column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )






# =========================================================
# DETECTED PATTERNS
# =========================================================

class EpisodePattern(Base):
    __tablename__ = "episode_patterns"

    id = Column(Integer, primary_key=True, autoincrement=True)
    pattern_id = Column(String(40), unique=True, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    category = Column(String(80), nullable=False, default="general")
    description = Column(Text, nullable=False)
    confidence = Column(Float, nullable=False)
    evidence = Column(JSON, nullable=False)
    status = Column(String(20), nullable=False, default="ACTIVE")
    first_seen_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    last_seen_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
