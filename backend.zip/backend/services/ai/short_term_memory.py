class ShortTermMemory:

    pass