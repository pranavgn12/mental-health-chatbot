class MemoryRAG:

    pass