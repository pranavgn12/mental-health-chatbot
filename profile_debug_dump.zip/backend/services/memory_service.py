def retrieve():

    return None